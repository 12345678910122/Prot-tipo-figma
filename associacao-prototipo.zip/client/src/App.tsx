import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Login from "./pages/Login";
import DashboardAssistenteSocial from "./pages/DashboardAssistenteSocial";
import DashboardAdministrativo from "./pages/DashboardAdministrativo";
import CadastroMulheres from "./pages/CadastroMulheres";
import GestaoSuprimentos from "./pages/GestaoSuprimentos";
import GestaoColaboradores from "./pages/GestaoColaboradores";
import FormularioContato from "./pages/FormularioContato";
import FormularioDoacao from "./pages/FormularioDoacao";
import FormularioVoluntario from "./pages/FormularioVoluntario";
import RegistroServicoSocial from "./pages/RegistroServicoSocial";
import AnaliseIntervencao from "./pages/AnaliseIntervencao";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/login"} component={Login} />
      <Route path={"/dashboard-as"} component={DashboardAssistenteSocial} />
      <Route path={"/dashboard-admin"} component={DashboardAdministrativo} />
      <Route path={"/cadastro-mulheres"} component={CadastroMulheres} />
      <Route path={"/gestao-suprimentos"} component={GestaoSuprimentos} />
      <Route path={"/gestao-colaboradores"} component={GestaoColaboradores} />
      <Route path={"/formulario-contato"} component={FormularioContato} />
      <Route path={"/formulario-doacao"} component={FormularioDoacao} />
      <Route path={"/formulario-voluntario"} component={FormularioVoluntario} />
      <Route path={"/registro-servico-social"} component={RegistroServicoSocial} />
      <Route path={"/analise-intervencao"} component={AnaliseIntervencao} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
