import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, Plus, Edit2, Trash2 } from "lucide-react";
import { useState } from "react";

export default function GestaoColaboradores() {
  const [, navigate] = useLocation();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    nome: "",
    contato: "",
    funcao: "",
    disponibilidade: "",
  });

  const [colaboradores] = useState([
    {
      id: 1,
      nome: "João Silva",
      contato: "(16) 99999-0001",
      funcao: "Voluntário",
      disponibilidade: "Fins de semana",
    },
    {
      id: 2,
      nome: "Carla Santos",
      contato: "(16) 99999-0002",
      funcao: "Coordenadora",
      disponibilidade: "Segunda a Sexta",
    },
    {
      id: 3,
      nome: "Pedro Costa",
      contato: "(16) 99999-0003",
      funcao: "Voluntário",
      disponibilidade: "Terça e Quinta",
    },
  ]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddColaborador = () => {
    if (formData.nome && formData.contato) {
      setShowForm(false);
      setFormData({
        nome: "",
        contato: "",
        funcao: "",
        disponibilidade: "",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Gestão de Colaboradores</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Botão Voltar */}
        <Button
          variant="outline"
          onClick={() => navigate("/dashboard-admin")}
          className="mb-6 border-primary text-primary hover:bg-gray-50 flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Button>

        {/* Botão Adicionar */}
        <div className="mb-6">
          <Button
            onClick={() => setShowForm(!showForm)}
            className="bg-primary hover:bg-purple-700 text-white flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Adicionar Colaborador
          </Button>
        </div>

        {/* Formulário de Adição */}
        {showForm && (
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <h3 className="text-xl font-bold text-gray-800 mb-6">
              Novo Colaborador
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Nome Completo *
                </label>
                <Input
                  type="text"
                  name="nome"
                  placeholder="Digite o nome completo"
                  value={formData.nome}
                  onChange={handleChange}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Contato *
                </label>
                <Input
                  type="text"
                  name="contato"
                  placeholder="(16) 99999-9999"
                  value={formData.contato}
                  onChange={handleChange}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Função
                </label>
                <Input
                  type="text"
                  name="funcao"
                  placeholder="Ex: Voluntário, Coordenador"
                  value={formData.funcao}
                  onChange={handleChange}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Disponibilidade
                </label>
                <Input
                  type="text"
                  name="disponibilidade"
                  placeholder="Ex: Fins de semana, Segunda a Sexta"
                  value={formData.disponibilidade}
                  onChange={handleChange}
                  className="w-full"
                />
              </div>
            </div>
            <div className="flex gap-4 mt-6">
              <Button
                variant="outline"
                onClick={() => setShowForm(false)}
                className="flex-1 border-primary text-primary hover:bg-gray-50"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleAddColaborador}
                className="flex-1 bg-primary hover:bg-purple-700 text-white"
              >
                Adicionar
              </Button>
            </div>
          </div>
        )}

        {/* Tabela de Colaboradores */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-100 border-b-2 border-primary">
                <tr>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Nome
                  </th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Contato
                  </th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Função
                  </th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Disponibilidade
                  </th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody>
                {colaboradores.map((colaborador) => (
                  <tr key={colaborador.id} className="border-b hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-700">{colaborador.nome}</td>
                    <td className="px-6 py-4 text-gray-700">
                      {colaborador.contato}
                    </td>
                    <td className="px-6 py-4 text-gray-700">{colaborador.funcao}</td>
                    <td className="px-6 py-4 text-gray-700">
                      {colaborador.disponibilidade}
                    </td>
                    <td className="px-6 py-4 flex gap-2">
                      <button className="text-blue-600 hover:text-blue-800 transition">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="text-red-600 hover:text-red-800 transition">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
