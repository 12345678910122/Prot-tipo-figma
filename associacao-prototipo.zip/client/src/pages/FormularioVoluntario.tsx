import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, Users } from "lucide-react";
import { useState } from "react";

export default function FormularioVoluntario() {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    nome: "",
    contato: "",
    areaInteresse: "",
    disponibilidade: "",
  });
  const [cadastrado, setCadastrado] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleRegister = () => {
    if (formData.nome && formData.contato) {
      setCadastrado(true);
      setTimeout(() => {
        navigate("/");
      }, 2000);
    }
  };

  if (cadastrado) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-md p-8 text-center max-w-md">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Bem-vindo ao Time!
          </h2>
          <p className="text-gray-600 mb-6">
            Obrigado por se cadastrar como voluntário. Entraremos em contato em breve.
          </p>
          <p className="text-sm text-gray-500">Redirecionando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Cadastro de Voluntário</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="bg-white rounded-lg shadow-md p-8">
          <div className="mb-8 p-6 bg-purple-50 rounded-lg border-l-4 border-primary">
            <p className="text-gray-700">
              Sua participação como voluntário é fundamental para ampliar o alcance e o impacto dos serviços prestados pela associação.
            </p>
          </div>

          {/* Formulário */}
          <form className="space-y-6">
            {/* Nome */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Nome Completo *
              </label>
              <Input
                type="text"
                name="nome"
                placeholder="Digite seu nome completo"
                value={formData.nome}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Contato */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Contato (Telefone/Email) *
              </label>
              <Input
                type="text"
                name="contato"
                placeholder="(16) 99999-9999 ou email@example.com"
                value={formData.contato}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Área de Interesse */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Área de Interesse
              </label>
              <select
                name="areaInteresse"
                value={formData.areaInteresse}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">Selecione uma área</option>
                <option value="atendimento">Atendimento Social</option>
                <option value="apoio">Apoio Emocional</option>
                <option value="administrativo">Administrativo</option>
                <option value="manutencao">Manutenção e Limpeza</option>
                <option value="alimentacao">Alimentação e Distribuição</option>
                <option value="comunicacao">Comunicação e Redes Sociais</option>
                <option value="outro">Outro</option>
              </select>
            </div>

            {/* Disponibilidade */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Disponibilidade
              </label>
              <select
                name="disponibilidade"
                value={formData.disponibilidade}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">Selecione sua disponibilidade</option>
                <option value="segunda-sexta">Segunda a Sexta</option>
                <option value="fins-semana">Fins de Semana</option>
                <option value="flexivel">Flexível</option>
                <option value="noturno">Noturno</option>
              </select>
            </div>

            {/* Informações Adicionais */}
            <div className="p-6 bg-gray-50 rounded-lg">
              <h3 className="text-lg font-bold text-gray-800 mb-4">
                Por que ser voluntário?
              </h3>
              <ul className="space-y-2 text-gray-700 list-disc list-inside">
                <li>Fazer diferença na vida de mulheres em situação vulnerável</li>
                <li>Contribuir para uma sociedade mais justa e igualitária</li>
                <li>Desenvolver novas habilidades e conhecimentos</li>
                <li>Conhecer pessoas com valores similares</li>
                <li>Ser parte de uma comunidade solidária</li>
              </ul>
            </div>

            {/* Botões */}
            <div className="flex gap-4 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/")}
                className="flex-1 border-primary text-primary hover:bg-gray-50 flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Cancelar
              </Button>
              <Button
                type="button"
                onClick={handleRegister}
                className="flex-1 bg-primary hover:bg-purple-700 text-white flex items-center justify-center gap-2"
              >
                <Users className="w-4 h-4" />
                Cadastrar-se
              </Button>
            </div>
          </form>

          {/* Nota */}
          <p className="text-xs text-gray-500 text-center mt-6">
            * Campos obrigatórios
          </p>
        </div>
      </div>
    </div>
  );
}
