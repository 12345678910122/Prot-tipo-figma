import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Heart, Users, Mail, DollarSign } from "lucide-react";

export default function Home() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-primary text-primary-foreground shadow-lg">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
              <Heart className="w-6 h-6 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">Estendendo as Mãos</h1>
          </div>
          <Button
            variant="secondary"
            onClick={() => navigate("/login")}
            className="bg-white text-primary hover:bg-gray-100"
          >
            Entrar no Sistema
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-purple-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">
            Estendendo as Mãos Para as Mulheres
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Assessorando, ajudando e respaldando mulheres em situação vulnerável
            e violência doméstica
          </p>
        </div>
      </section>

      {/* Missão, Visão e Valores */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12 text-primary">
            Missão, Visão e Valores
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md border-l-4 border-primary">
              <h4 className="text-xl font-bold text-primary mb-4">Missão</h4>
              <p className="text-gray-700">
                Assessorar, ajudar e respaldar mulheres em situação vulnerável
                e/ou vítimas de violência doméstica, oferecendo suporte
                emocional, social e material.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md border-l-4 border-primary">
              <h4 className="text-xl font-bold text-primary mb-4">Visão</h4>
              <p className="text-gray-700">
                Ser uma referência na comunidade para o acolhimento e proteção
                de mulheres, contribuindo para uma sociedade mais justa e
                igualitária.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md border-l-4 border-primary">
              <h4 className="text-xl font-bold text-primary mb-4">Valores</h4>
              <p className="text-gray-700">
                Respeito, dignidade, solidariedade, empatia e compromisso com a
                transformação social e a igualdade de gênero.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Serviços */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12 text-primary">
            Nossos Serviços
          </h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 bg-primary text-white rounded-lg flex items-center justify-center flex-shrink-0">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-primary mb-2">
                  Atendimento Social
                </h4>
                <p className="text-gray-700">
                  Análise e intervenção social para mulheres em situação de
                  vulnerabilidade.
                </p>
              </div>
            </div>
            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 bg-primary text-white rounded-lg flex items-center justify-center flex-shrink-0">
                <Heart className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-primary mb-2">
                  Apoio Emocional
                </h4>
                <p className="text-gray-700">
                  Suporte emocional e acompanhamento para mulheres vítimas de
                  violência.
                </p>
              </div>
            </div>
            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 bg-primary text-white rounded-lg flex items-center justify-center flex-shrink-0">
                <DollarSign className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-primary mb-2">
                  Auxílio Material
                </h4>
                <p className="text-gray-700">
                  Distribuição de cestas básicas e outros recursos essenciais.
                </p>
              </div>
            </div>
            <div className="flex gap-4 items-start">
              <div className="w-12 h-12 bg-primary text-white rounded-lg flex items-center justify-center flex-shrink-0">
                <Mail className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-primary mb-2">
                  Orientação
                </h4>
                <p className="text-gray-700">
                  Orientação sobre direitos, encaminhamentos e recursos
                  disponíveis.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Chamadas para Ação */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12 text-primary">
            Como Você Pode Ajudar
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <DollarSign className="w-12 h-12 text-primary mx-auto mb-4" />
              <h4 className="text-xl font-bold text-primary mb-4">Fazer Doação</h4>
              <p className="text-gray-700 mb-6">
                Sua doação ajuda a manter nossos serviços funcionando.
              </p>
              <Button
                onClick={() => navigate("/formulario-doacao")}
                className="w-full bg-primary hover:bg-purple-700 text-white"
              >
                Fazer Doação
              </Button>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <Users className="w-12 h-12 text-primary mx-auto mb-4" />
              <h4 className="text-xl font-bold text-primary mb-4">
                Seja Voluntário
              </h4>
              <p className="text-gray-700 mb-6">
                Junte-se ao nosso time e faça a diferença na vida de mulheres.
              </p>
              <Button
                onClick={() => navigate("/formulario-voluntario")}
                className="w-full bg-primary hover:bg-purple-700 text-white"
              >
                Cadastrar-se
              </Button>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <Mail className="w-12 h-12 text-primary mx-auto mb-4" />
              <h4 className="text-xl font-bold text-primary mb-4">Contato</h4>
              <p className="text-gray-700 mb-6">
                Tem dúvidas? Entre em contato conosco.
              </p>
              <Button
                onClick={() => navigate("/formulario-contato")}
                variant="outline"
                className="w-full border-primary text-primary hover:bg-gray-50"
              >
                Enviar Mensagem
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Contato e Informações */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12">
            Informações de Contato
          </h3>
          <div className="grid md:grid-cols-2 gap-8 text-center">
            <div>
              <h4 className="text-xl font-bold mb-2">Telefone</h4>
              <p className="text-lg">(16) 99999-9999</p>
            </div>
            <div>
              <h4 className="text-xl font-bold mb-2">Email</h4>
              <p className="text-lg">contato@estendendoasmaos.org.br</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="mb-4">
            © 2025 Associação Estendendo as Mãos Para as Mulheres. Todos os
            direitos reservados.
          </p>
          <div className="flex justify-center gap-6">
            <a href="#" className="hover:text-primary transition">
              Facebook
            </a>
            <a href="#" className="hover:text-primary transition">
              Instagram
            </a>
            <a href="#" className="hover:text-primary transition">
              WhatsApp
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
