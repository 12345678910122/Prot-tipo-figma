import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, Save } from "lucide-react";
import { useState } from "react";

export default function CadastroMulheres() {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    nome: "",
    contato: "",
    endereco: "",
    documentacao: "",
    historico: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    if (formData.nome && formData.contato) {
      navigate("/dashboard-as");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Cadastrar Mulher</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="bg-white rounded-lg shadow-md p-8">
          {/* Formulário */}
          <form className="space-y-6">
            {/* Nome */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Nome Completo *
              </label>
              <Input
                type="text"
                name="nome"
                placeholder="Digite o nome completo"
                value={formData.nome}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Contato */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Contato (Telefone/Email) *
              </label>
              <Input
                type="text"
                name="contato"
                placeholder="(16) 99999-9999 ou email@example.com"
                value={formData.contato}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Endereço */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Endereço
              </label>
              <Input
                type="text"
                name="endereco"
                placeholder="Rua, número, bairro, cidade"
                value={formData.endereco}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Documentação */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Documentação (CPF, RG, etc)
              </label>
              <Input
                type="text"
                name="documentacao"
                placeholder="Informações de documentação"
                value={formData.documentacao}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Histórico */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Histórico / Observações
              </label>
              <textarea
                name="historico"
                placeholder="Descreva o histórico e situação atual"
                value={formData.historico}
                onChange={handleChange}
                rows={5}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            {/* Botões */}
            <div className="flex gap-4 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/dashboard-as")}
                className="flex-1 border-primary text-primary hover:bg-gray-50 flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Cancelar
              </Button>
              <Button
                type="button"
                onClick={handleSave}
                className="flex-1 bg-primary hover:bg-purple-700 text-white flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                Salvar Cadastro
              </Button>
            </div>
          </form>

          {/* Nota */}
          <p className="text-xs text-gray-500 text-center mt-6">
            * Campos obrigatórios
          </p>
        </div>
      </div>
    </div>
  );
}
