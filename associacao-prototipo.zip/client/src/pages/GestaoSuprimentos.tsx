import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, Plus, Edit2, Trash2 } from "lucide-react";
import { useState } from "react";

export default function GestaoSuprimentos() {
  const [, navigate] = useLocation();
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    tipo: "",
    quantidade: "",
    data: "",
    doador: "",
    validade: "",
  });

  const [suprimentos] = useState([
    {
      id: 1,
      tipo: "Arroz",
      quantidade: "50 kg",
      data: "01/05/2025",
      doador: "Doador Anônimo",
      validade: "12/2025",
    },
    {
      id: 2,
      tipo: "Feijão",
      quantidade: "30 kg",
      data: "02/05/2025",
      doador: "Empresa XYZ",
      validade: "11/2025",
    },
    {
      id: 3,
      tipo: "Óleo",
      quantidade: "20 L",
      data: "03/05/2025",
      doador: "Doador Anônimo",
      validade: "10/2025",
    },
  ]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddSuprimento = () => {
    if (formData.tipo && formData.quantidade) {
      setShowForm(false);
      setFormData({
        tipo: "",
        quantidade: "",
        data: "",
        doador: "",
        validade: "",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Gestão de Suprimentos</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Botão Voltar */}
        <Button
          variant="outline"
          onClick={() => navigate("/dashboard-admin")}
          className="mb-6 border-primary text-primary hover:bg-gray-50 flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Button>

        {/* Botão Adicionar */}
        <div className="mb-6">
          <Button
            onClick={() => setShowForm(!showForm)}
            className="bg-primary hover:bg-purple-700 text-white flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Adicionar Suprimento
          </Button>
        </div>

        {/* Formulário de Adição */}
        {showForm && (
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <h3 className="text-xl font-bold text-gray-800 mb-6">
              Novo Suprimento
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Tipo de Suprimento *
                </label>
                <Input
                  type="text"
                  name="tipo"
                  placeholder="Ex: Arroz, Feijão, Óleo"
                  value={formData.tipo}
                  onChange={handleChange}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Quantidade *
                </label>
                <Input
                  type="text"
                  name="quantidade"
                  placeholder="Ex: 50 kg, 20 L"
                  value={formData.quantidade}
                  onChange={handleChange}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Data de Recebimento
                </label>
                <Input
                  type="date"
                  name="data"
                  value={formData.data}
                  onChange={handleChange}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Doador
                </label>
                <Input
                  type="text"
                  name="doador"
                  placeholder="Nome do doador"
                  value={formData.doador}
                  onChange={handleChange}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Data de Validade
                </label>
                <Input
                  type="month"
                  name="validade"
                  value={formData.validade}
                  onChange={handleChange}
                  className="w-full"
                />
              </div>
            </div>
            <div className="flex gap-4 mt-6">
              <Button
                variant="outline"
                onClick={() => setShowForm(false)}
                className="flex-1 border-primary text-primary hover:bg-gray-50"
              >
                Cancelar
              </Button>
              <Button
                onClick={handleAddSuprimento}
                className="flex-1 bg-primary hover:bg-purple-700 text-white"
              >
                Adicionar
              </Button>
            </div>
          </div>
        )}

        {/* Tabela de Suprimentos */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-100 border-b-2 border-primary">
                <tr>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Tipo
                  </th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Quantidade
                  </th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Data Recebimento
                  </th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Doador
                  </th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Validade
                  </th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody>
                {suprimentos.map((suprimento) => (
                  <tr key={suprimento.id} className="border-b hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-700">{suprimento.tipo}</td>
                    <td className="px-6 py-4 text-gray-700">
                      {suprimento.quantidade}
                    </td>
                    <td className="px-6 py-4 text-gray-700">{suprimento.data}</td>
                    <td className="px-6 py-4 text-gray-700">
                      {suprimento.doador}
                    </td>
                    <td className="px-6 py-4 text-gray-700">
                      {suprimento.validade}
                    </td>
                    <td className="px-6 py-4 flex gap-2">
                      <button className="text-blue-600 hover:text-blue-800 transition">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="text-red-600 hover:text-red-800 transition">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
