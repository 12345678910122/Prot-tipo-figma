import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { LogOut, Users, FileText, BarChart3 } from "lucide-react";

export default function DashboardAssistenteSocial() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Dashboard - Assistente Social</h1>
          <Button
            variant="secondary"
            onClick={() => navigate("/")}
            className="bg-white text-primary hover:bg-gray-100 flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            Sair
          </Button>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white shadow-lg min-h-screen p-6">
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-primary mb-6">Menu</h3>
            <nav className="space-y-2">
              <button
                onClick={() => navigate("/dashboard-as")}
                className="w-full text-left px-4 py-3 rounded-lg bg-primary text-white font-semibold"
              >
                Dashboard
              </button>
              <button
                onClick={() => navigate("/cadastro-mulheres")}
                className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-100 text-gray-700 font-semibold transition"
              >
                Cadastrar Mulher
              </button>
              <button
                onClick={() => navigate("/registro-servico-social")}
                className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-100 text-gray-700 font-semibold transition"
              >
                Registrar Serviço Social
              </button>
              <button
                onClick={() => navigate("/analise-intervencao")}
                className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-100 text-gray-700 font-semibold transition"
              >
                Análise e Intervenção
              </button>
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {/* Bem-vindo */}
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-2">
              Bem-vindo, Assistente Social
            </h2>
            <p className="text-gray-600">
              Gerencie os atendimentos e registros das mulheres assistidas.
            </p>
          </div>

          {/* Cards de Ação Rápida */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <button
              onClick={() => navigate("/cadastro-mulheres")}
              className="bg-white rounded-lg shadow-md p-8 hover:shadow-lg transition text-left border-l-4 border-primary"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary text-white rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-primary">
                    Cadastrar Mulher
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Registre uma nova mulher atendida
                  </p>
                </div>
              </div>
            </button>

            <button
              onClick={() => navigate("/registro-servico-social")}
              className="bg-white rounded-lg shadow-md p-8 hover:shadow-lg transition text-left border-l-4 border-primary"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary text-white rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-primary">
                    Registrar Serviço
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Documente o atendimento realizado
                  </p>
                </div>
              </div>
            </button>

            <button
              onClick={() => navigate("/analise-intervencao")}
              className="bg-white rounded-lg shadow-md p-8 hover:shadow-lg transition text-left border-l-4 border-primary"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary text-white rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-primary">
                    Análise e Intervenção
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Avalie a situação das mulheres
                  </p>
                </div>
              </div>
            </button>
          </div>

          {/* Resumo de Mulheres */}
          <div className="bg-white rounded-lg shadow-md p-8">
            <h3 className="text-2xl font-bold text-gray-800 mb-6">
              Mulheres Atendidas (Resumo)
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-100 border-b-2 border-primary">
                  <tr>
                    <th className="px-6 py-3 text-left font-semibold text-gray-700">
                      ID
                    </th>
                    <th className="px-6 py-3 text-left font-semibold text-gray-700">
                      Nome
                    </th>
                    <th className="px-6 py-3 text-left font-semibold text-gray-700">
                      Contato
                    </th>
                    <th className="px-6 py-3 text-left font-semibold text-gray-700">
                      Data de Cadastro
                    </th>
                    <th className="px-6 py-3 text-left font-semibold text-gray-700">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-700">001</td>
                    <td className="px-6 py-4 text-gray-700">Maria Silva</td>
                    <td className="px-6 py-4 text-gray-700">(16) 99999-0001</td>
                    <td className="px-6 py-4 text-gray-700">01/05/2025</td>
                    <td className="px-6 py-4">
                      <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                        Ativo
                      </span>
                    </td>
                  </tr>
                  <tr className="border-b hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-700">002</td>
                    <td className="px-6 py-4 text-gray-700">Ana Santos</td>
                    <td className="px-6 py-4 text-gray-700">(16) 99999-0002</td>
                    <td className="px-6 py-4 text-gray-700">02/05/2025</td>
                    <td className="px-6 py-4">
                      <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                        Ativo
                      </span>
                    </td>
                  </tr>
                  <tr className="border-b hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-700">003</td>
                    <td className="px-6 py-4 text-gray-700">Paula Costa</td>
                    <td className="px-6 py-4 text-gray-700">(16) 99999-0003</td>
                    <td className="px-6 py-4 text-gray-700">03/05/2025</td>
                    <td className="px-6 py-4">
                      <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-semibold">
                        Em Acompanhamento
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
