import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, Save } from "lucide-react";
import { useState } from "react";

export default function RegistroServicoSocial() {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    mulherNome: "",
    dataAtendimento: "",
    tipoServico: "",
    descricao: "",
    encaminhamentos: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    if (formData.mulherNome && formData.dataAtendimento && formData.tipoServico) {
      navigate("/dashboard-as");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Registrar Serviço Social</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="bg-white rounded-lg shadow-md p-8">
          {/* Formulário */}
          <form className="space-y-6">
            {/* Nome da Mulher */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Nome da Mulher Atendida *
              </label>
              <Input
                type="text"
                name="mulherNome"
                placeholder="Digite o nome"
                value={formData.mulherNome}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Data do Atendimento */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Data do Atendimento *
              </label>
              <Input
                type="date"
                name="dataAtendimento"
                value={formData.dataAtendimento}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Tipo de Serviço */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Tipo de Serviço *
              </label>
              <select
                name="tipoServico"
                value={formData.tipoServico}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">Selecione o tipo de serviço</option>
                <option value="acolhimento">Acolhimento</option>
                <option value="orientacao">Orientação</option>
                <option value="encaminhamento">Encaminhamento</option>
                <option value="apoio-emocional">Apoio Emocional</option>
                <option value="auxilio-material">Auxílio Material</option>
                <option value="outro">Outro</option>
              </select>
            </div>

            {/* Descrição do Atendimento */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Descrição do Atendimento
              </label>
              <textarea
                name="descricao"
                placeholder="Descreva o atendimento realizado"
                value={formData.descricao}
                onChange={handleChange}
                rows={5}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            {/* Encaminhamentos */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Encaminhamentos Realizados
              </label>
              <textarea
                name="encaminhamentos"
                placeholder="Descreva os encaminhamentos realizados (se houver)"
                value={formData.encaminhamentos}
                onChange={handleChange}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            {/* Botões */}
            <div className="flex gap-4 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/dashboard-as")}
                className="flex-1 border-primary text-primary hover:bg-gray-50 flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Cancelar
              </Button>
              <Button
                type="button"
                onClick={handleSave}
                className="flex-1 bg-primary hover:bg-purple-700 text-white flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                Salvar Registro
              </Button>
            </div>
          </form>

          {/* Nota */}
          <p className="text-xs text-gray-500 text-center mt-6">
            * Campos obrigatórios
          </p>
        </div>
      </div>
    </div>
  );
}
