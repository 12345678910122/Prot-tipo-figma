import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, Send } from "lucide-react";
import { useState } from "react";

export default function FormularioContato() {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    assunto: "",
    mensagem: "",
  });
  const [enviado, setEnviado] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSend = () => {
    if (formData.nome && formData.email && formData.mensagem) {
      setEnviado(true);
      setTimeout(() => {
        navigate("/");
      }, 2000);
    }
  };

  if (enviado) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-md p-8 text-center max-w-md">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg
              className="w-8 h-8 text-green-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Mensagem Enviada!
          </h2>
          <p className="text-gray-600 mb-6">
            Obrigado por entrar em contato. Retornaremos em breve.
          </p>
          <p className="text-sm text-gray-500">Redirecionando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Formulário de Contato</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="bg-white rounded-lg shadow-md p-8">
          {/* Formulário */}
          <form className="space-y-6">
            {/* Nome */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Nome Completo *
              </label>
              <Input
                type="text"
                name="nome"
                placeholder="Digite seu nome"
                value={formData.nome}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Email *
              </label>
              <Input
                type="email"
                name="email"
                placeholder="seu.email@example.com"
                value={formData.email}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Assunto */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Assunto
              </label>
              <Input
                type="text"
                name="assunto"
                placeholder="Assunto da mensagem"
                value={formData.assunto}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Mensagem */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Mensagem *
              </label>
              <textarea
                name="mensagem"
                placeholder="Digite sua mensagem"
                value={formData.mensagem}
                onChange={handleChange}
                rows={6}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            {/* Botões */}
            <div className="flex gap-4 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/")}
                className="flex-1 border-primary text-primary hover:bg-gray-50 flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Cancelar
              </Button>
              <Button
                type="button"
                onClick={handleSend}
                className="flex-1 bg-primary hover:bg-purple-700 text-white flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                Enviar Mensagem
              </Button>
            </div>
          </form>

          {/* Nota */}
          <p className="text-xs text-gray-500 text-center mt-6">
            * Campos obrigatórios
          </p>
        </div>
      </div>
    </div>
  );
}
