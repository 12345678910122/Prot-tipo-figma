import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { Heart, LogIn } from "lucide-react";
import { useState } from "react";

export default function Login() {
  const [, navigate] = useLocation();
  const [perfil, setPerfil] = useState<"as" | "admin">("as");
  const [usuario, setUsuario] = useState("");
  const [senha, setSenha] = useState("");

  const handleLogin = () => {
    if (usuario && senha) {
      if (perfil === "as") {
        navigate("/dashboard-as");
      } else {
        navigate("/dashboard-admin");
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl p-8 w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <div className="w-16 h-16 bg-primary text-white rounded-lg flex items-center justify-center">
            <Heart className="w-8 h-8" />
          </div>
        </div>

        <h1 className="text-3xl font-bold text-center text-primary mb-2">
          Estendendo as Mãos
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Sistema de Gestão
        </p>

        {/* Formulário */}
        <div className="space-y-6">
          {/* Seletor de Perfil */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              Tipo de Acesso
            </label>
            <div className="flex gap-4">
              <button
                onClick={() => setPerfil("as")}
                className={`flex-1 py-3 px-4 rounded-lg font-semibold transition ${
                  perfil === "as"
                    ? "bg-primary text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Assistente Social
              </button>
              <button
                onClick={() => setPerfil("admin")}
                className={`flex-1 py-3 px-4 rounded-lg font-semibold transition ${
                  perfil === "admin"
                    ? "bg-primary text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Administrativo
              </button>
            </div>
          </div>

          {/* Campo de Usuário */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Usuário
            </label>
            <Input
              type="text"
              placeholder="Digite seu usuário"
              value={usuario}
              onChange={(e) => setUsuario(e.target.value)}
              className="w-full"
            />
          </div>

          {/* Campo de Senha */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Senha
            </label>
            <Input
              type="password"
              placeholder="Digite sua senha"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              className="w-full"
            />
          </div>

          {/* Botões */}
          <div className="flex gap-4 pt-4">
            <Button
              variant="outline"
              onClick={() => navigate("/")}
              className="flex-1 border-primary text-primary hover:bg-gray-50"
            >
              Voltar
            </Button>
            <Button
              onClick={handleLogin}
              className="flex-1 bg-primary hover:bg-purple-700 text-white flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              Entrar
            </Button>
          </div>
        </div>

        {/* Nota */}
        <p className="text-xs text-gray-500 text-center mt-6">
          Para fins de demonstração, qualquer usuário e senha funcionam.
        </p>
      </div>
    </div>
  );
}
