import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { LogOut, Package, Users, BarChart3 } from "lucide-react";

export default function DashboardAdministrativo() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Dashboard - Administrativo</h1>
          <Button
            variant="secondary"
            onClick={() => navigate("/")}
            className="bg-white text-primary hover:bg-gray-100 flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            Sair
          </Button>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white shadow-lg min-h-screen p-6">
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-primary mb-6">Menu</h3>
            <nav className="space-y-2">
              <button
                onClick={() => navigate("/dashboard-admin")}
                className="w-full text-left px-4 py-3 rounded-lg bg-primary text-white font-semibold"
              >
                Dashboard
              </button>
              <button
                onClick={() => navigate("/gestao-colaboradores")}
                className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-100 text-gray-700 font-semibold transition"
              >
                Colaboradores
              </button>
              <button
                onClick={() => navigate("/gestao-suprimentos")}
                className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-100 text-gray-700 font-semibold transition"
              >
                Suprimentos
              </button>
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {/* Bem-vindo */}
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-2">
              Bem-vindo, Administrativo
            </h2>
            <p className="text-gray-600">
              Gerencie colaboradores, voluntários e suprimentos da associação.
            </p>
          </div>

          {/* Cards de Ação Rápida */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <button
              onClick={() => navigate("/gestao-colaboradores")}
              className="bg-white rounded-lg shadow-md p-8 hover:shadow-lg transition text-left border-l-4 border-primary"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary text-white rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-primary">
                    Colaboradores
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Gerencie voluntários e colaboradores
                  </p>
                </div>
              </div>
            </button>

            <button
              onClick={() => navigate("/gestao-suprimentos")}
              className="bg-white rounded-lg shadow-md p-8 hover:shadow-lg transition text-left border-l-4 border-primary"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary text-white rounded-lg flex items-center justify-center">
                  <Package className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-primary">
                    Suprimentos
                  </h3>
                  <p className="text-gray-600 text-sm">
                    Controle estoque e doações
                  </p>
                </div>
              </div>
            </button>

            <div className="bg-white rounded-lg shadow-md p-8 border-l-4 border-primary">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary text-white rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-primary">Relatórios</h3>
                  <p className="text-gray-600 text-sm">
                    Visualize estatísticas
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Resumo de Colaboradores */}
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg shadow-md p-8">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">
                Colaboradores (Resumo)
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-100 border-b-2 border-primary">
                    <tr>
                      <th className="px-6 py-3 text-left font-semibold text-gray-700">
                        Nome
                      </th>
                      <th className="px-6 py-3 text-left font-semibold text-gray-700">
                        Função
                      </th>
                      <th className="px-6 py-3 text-left font-semibold text-gray-700">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="px-6 py-4 text-gray-700">João Silva</td>
                      <td className="px-6 py-4 text-gray-700">Voluntário</td>
                      <td className="px-6 py-4">
                        <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                          Ativo
                        </span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="px-6 py-4 text-gray-700">
                        Carla Santos
                      </td>
                      <td className="px-6 py-4 text-gray-700">Coordenadora</td>
                      <td className="px-6 py-4">
                        <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                          Ativo
                        </span>
                      </td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="px-6 py-4 text-gray-700">Pedro Costa</td>
                      <td className="px-6 py-4 text-gray-700">Voluntário</td>
                      <td className="px-6 py-4">
                        <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-semibold">
                          Disponível
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <Button
                onClick={() => navigate("/gestao-colaboradores")}
                className="mt-4 w-full bg-primary hover:bg-purple-700 text-white"
              >
                Ver Todos
              </Button>
            </div>

            {/* Resumo de Suprimentos */}
            <div className="bg-white rounded-lg shadow-md p-8">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">
                Suprimentos (Resumo)
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-100 border-b-2 border-primary">
                    <tr>
                      <th className="px-6 py-3 text-left font-semibold text-gray-700">
                        Tipo
                      </th>
                      <th className="px-6 py-3 text-left font-semibold text-gray-700">
                        Quantidade
                      </th>
                      <th className="px-6 py-3 text-left font-semibold text-gray-700">
                        Validade
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="px-6 py-4 text-gray-700">Arroz</td>
                      <td className="px-6 py-4 text-gray-700">50 kg</td>
                      <td className="px-6 py-4 text-gray-700">12/2025</td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="px-6 py-4 text-gray-700">Feijão</td>
                      <td className="px-6 py-4 text-gray-700">30 kg</td>
                      <td className="px-6 py-4 text-gray-700">11/2025</td>
                    </tr>
                    <tr className="border-b hover:bg-gray-50">
                      <td className="px-6 py-4 text-gray-700">Óleo</td>
                      <td className="px-6 py-4 text-gray-700">20 L</td>
                      <td className="px-6 py-4 text-gray-700">10/2025</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <Button
                onClick={() => navigate("/gestao-suprimentos")}
                className="mt-4 w-full bg-primary hover:bg-purple-700 text-white"
              >
                Ver Todos
              </Button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
