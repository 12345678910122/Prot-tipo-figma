import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, Heart } from "lucide-react";
import { useState } from "react";

export default function FormularioDoacao() {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    valor: "",
    tipo: "dinheiro",
  });
  const [doado, setDoado] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleDonate = () => {
    if (formData.valor) {
      setDoado(true);
      setTimeout(() => {
        navigate("/");
      }, 2000);
    }
  };

  if (doado) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-md p-8 text-center max-w-md">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Obrigado pela Doação!
          </h2>
          <p className="text-gray-600 mb-6">
            Sua contribuição é fundamental para ajudar as mulheres atendidas pela associação.
          </p>
          <p className="text-sm text-gray-500">Redirecionando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Fazer uma Doação</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="bg-white rounded-lg shadow-md p-8">
          <div className="mb-8 p-6 bg-purple-50 rounded-lg border-l-4 border-primary">
            <p className="text-gray-700">
              Sua doação ajuda a associação a manter seus serviços e atender mais mulheres em situação de vulnerabilidade.
            </p>
          </div>

          {/* Formulário */}
          <form className="space-y-6">
            {/* Tipo de Doação */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Tipo de Doação
              </label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="tipo"
                    value="dinheiro"
                    checked={formData.tipo === "dinheiro"}
                    onChange={handleChange}
                    className="w-4 h-4 text-primary"
                  />
                  <span className="text-gray-700">Doação em Dinheiro</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="tipo"
                    value="mantimentos"
                    checked={formData.tipo === "mantimentos"}
                    onChange={handleChange}
                    className="w-4 h-4 text-primary"
                  />
                  <span className="text-gray-700">Doação de Mantimentos</span>
                </label>
              </div>
            </div>

            {/* Valor */}
            {formData.tipo === "dinheiro" && (
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Valor da Doação (R$) *
                </label>
                <Input
                  type="number"
                  name="valor"
                  placeholder="Digite o valor"
                  value={formData.valor}
                  onChange={handleChange}
                  className="w-full"
                  step="0.01"
                  min="0"
                />
              </div>
            )}

            {/* Informações Bancárias */}
            {formData.tipo === "dinheiro" && (
              <div className="p-6 bg-gray-50 rounded-lg">
                <h3 className="text-lg font-bold text-gray-800 mb-4">
                  Dados Bancários para Transferência
                </h3>
                <div className="space-y-2 text-gray-700">
                  <p>
                    <span className="font-semibold">Banco:</span> Banco do Brasil
                  </p>
                  <p>
                    <span className="font-semibold">Agência:</span> 1234-5
                  </p>
                  <p>
                    <span className="font-semibold">Conta:</span> 123456-7
                  </p>
                  <p>
                    <span className="font-semibold">Titular:</span> Associação
                    Estendendo as Mãos Para as Mulheres
                  </p>
                  <p>
                    <span className="font-semibold">CNPJ:</span> 12.345.678/0001-90
                  </p>
                </div>
              </div>
            )}

            {/* Informações sobre Mantimentos */}
            {formData.tipo === "mantimentos" && (
              <div className="p-6 bg-gray-50 rounded-lg">
                <h3 className="text-lg font-bold text-gray-800 mb-4">
                  Como Doar Mantimentos
                </h3>
                <ul className="space-y-2 text-gray-700 list-disc list-inside">
                  <li>Alimentos não perecíveis (arroz, feijão, óleo, etc)</li>
                  <li>Produtos de higiene pessoal</li>
                  <li>Roupas e calçados em bom estado</li>
                  <li>Produtos de limpeza</li>
                  <li>Leite e derivados (se refrigerados)</li>
                </ul>
                <p className="mt-4 text-gray-700">
                  <span className="font-semibold">Contato para agendamento:</span>{" "}
                  (16) 99999-9999
                </p>
              </div>
            )}

            {/* Botões */}
            <div className="flex gap-4 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/")}
                className="flex-1 border-primary text-primary hover:bg-gray-50 flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Cancelar
              </Button>
              <Button
                type="button"
                onClick={handleDonate}
                className="flex-1 bg-primary hover:bg-purple-700 text-white flex items-center justify-center gap-2"
              >
                <Heart className="w-4 h-4" />
                Confirmar Doação
              </Button>
            </div>
          </form>

          {/* Nota */}
          {formData.tipo === "dinheiro" && (
            <p className="text-xs text-gray-500 text-center mt-6">
              * Campo obrigatório
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
