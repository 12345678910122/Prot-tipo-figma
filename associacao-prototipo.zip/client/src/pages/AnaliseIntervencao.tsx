import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, Save } from "lucide-react";
import { useState } from "react";

export default function AnaliseIntervencao() {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    mulherNome: "",
    dataAnalise: "",
    nivelVulnerabilidade: "",
    situacaoAtual: "",
    planoIntervencao: "",
    observacoes: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    if (formData.mulherNome && formData.dataAnalise && formData.nivelVulnerabilidade) {
      navigate("/dashboard-as");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold">Análise e Intervenção Social</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="bg-white rounded-lg shadow-md p-8">
          {/* Formulário */}
          <form className="space-y-6">
            {/* Nome da Mulher */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Nome da Mulher *
              </label>
              <Input
                type="text"
                name="mulherNome"
                placeholder="Digite o nome"
                value={formData.mulherNome}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Data da Análise */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Data da Análise *
              </label>
              <Input
                type="date"
                name="dataAnalise"
                value={formData.dataAnalise}
                onChange={handleChange}
                className="w-full"
              />
            </div>

            {/* Nível de Vulnerabilidade */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Nível de Vulnerabilidade *
              </label>
              <select
                name="nivelVulnerabilidade"
                value={formData.nivelVulnerabilidade}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">Selecione o nível</option>
                <option value="baixo">Baixo</option>
                <option value="medio">Médio</option>
                <option value="alto">Alto</option>
                <option value="critico">Crítico</option>
              </select>
            </div>

            {/* Situação Atual */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Situação Atual
              </label>
              <textarea
                name="situacaoAtual"
                placeholder="Descreva a situação atual da mulher"
                value={formData.situacaoAtual}
                onChange={handleChange}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            {/* Plano de Intervenção */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Plano de Intervenção
              </label>
              <textarea
                name="planoIntervencao"
                placeholder="Descreva o plano de intervenção proposto"
                value={formData.planoIntervencao}
                onChange={handleChange}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            {/* Observações */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Observações Adicionais
              </label>
              <textarea
                name="observacoes"
                placeholder="Adicione observações importantes"
                value={formData.observacoes}
                onChange={handleChange}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            {/* Botões */}
            <div className="flex gap-4 pt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/dashboard-as")}
                className="flex-1 border-primary text-primary hover:bg-gray-50 flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Cancelar
              </Button>
              <Button
                type="button"
                onClick={handleSave}
                className="flex-1 bg-primary hover:bg-purple-700 text-white flex items-center justify-center gap-2"
              >
                <Save className="w-4 h-4" />
                Salvar Análise
              </Button>
            </div>
          </form>

          {/* Nota */}
          <p className="text-xs text-gray-500 text-center mt-6">
            * Campos obrigatórios
          </p>
        </div>
      </div>
    </div>
  );
}
