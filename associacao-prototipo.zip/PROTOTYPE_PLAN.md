# Plano de Protótipo Interativo - Associação Estendendo as Mãos Para as Mulheres

## Visão Geral
Protótipo interativo (estilo Figma) com navegação funcional entre telas, cores roxo (#7C3AED) e branco (#FFFFFF), baseado nos requisitos do documento de análise.

## Estrutura de Telas

### 1. Landing Page (Tela Inicial)
- **Componentes:**
  - Header com logo e navegação
  - Hero section com apresentação
  - Seção de Missão, Visão e Valores
  - Seção de Contato
  - Seção de Doações
  - Seção de Voluntários
  - Footer com links de redes sociais
- **Botões de Navegação:**
  - "Entrar no Sistema" → Tela de Login
  - "Fazer Doação" → Formulário de Doação
  - "Seja Voluntário" → Formulário de Voluntário
  - "Contato" → Formulário de Contato

### 2. Tela de Login
- **Componentes:**
  - Logo da associação
  - Campo de usuário/email
  - Campo de senha
  - Seletor de perfil (Assistente Social / Administrativo)
  - Botão "Entrar"
- **Navegação:**
  - Botão "Voltar" → Landing Page
  - Botão "Entrar" → Dashboard correspondente ao perfil

### 3. Dashboard - Assistente Social
- **Componentes:**
  - Sidebar com menu de navegação
  - Bem-vindo ao usuário
  - Botões de ação rápida
  - Lista de mulheres atendidas (resumo)
- **Botões de Navegação:**
  - "Cadastrar Mulher" → Cadastro de Mulheres
  - "Registrar Serviço Social" → Formulário de Serviço Social
  - "Análise e Intervenção" → Formulário de Análise
  - "Logout" → Landing Page

### 4. Dashboard - Administrativo
- **Componentes:**
  - Sidebar com menu de navegação
  - Bem-vindo ao usuário
  - Botões de ação rápida
  - Resumo de suprimentos e colaboradores
- **Botões de Navegação:**
  - "Cadastrar Colaborador" → Gestão de Colaboradores
  - "Cadastrar Suprimento" → Gestão de Suprimentos
  - "Ver Estoque" → Listagem de Estoque
  - "Logout" → Landing Page

### 5. Cadastro de Mulheres
- **Componentes:**
  - Formulário com campos: Nome, Contato, Endereço, Documentação, Histórico
  - Botão "Salvar"
  - Botão "Cancelar"
- **Navegação:**
  - "Cancelar" → Dashboard Assistente Social
  - "Salvar" → Dashboard Assistente Social (com mensagem de sucesso)

### 6. Gestão de Suprimentos
- **Componentes:**
  - Formulário: Tipo, Quantidade, Data, Doador, Validade
  - Tabela de suprimentos cadastrados
  - Botões "Adicionar", "Editar", "Deletar"
- **Navegação:**
  - "Voltar" → Dashboard Administrativo
  - "Adicionar" → Formulário de Suprimento

### 7. Gestão de Colaboradores
- **Componentes:**
  - Formulário: Nome, Contato, Função, Disponibilidade
  - Tabela de colaboradores cadastrados
  - Botões "Adicionar", "Editar", "Deletar"
- **Navegação:**
  - "Voltar" → Dashboard Administrativo
  - "Adicionar" → Formulário de Colaborador

### 8. Formulário de Contato (Landing Page)
- **Componentes:**
  - Campo Nome
  - Campo Email
  - Campo Assunto
  - Campo Mensagem
  - Botão "Enviar"
- **Navegação:**
  - "Enviar" → Mensagem de sucesso + volta para Landing Page
  - "Cancelar" → Landing Page

### 9. Formulário de Doação (Landing Page)
- **Componentes:**
  - Campo Valor
  - Informações bancárias
  - Informações sobre doação de mantimentos
  - Botão "Confirmar Doação"
- **Navegação:**
  - "Confirmar" → Mensagem de sucesso + volta para Landing Page
  - "Cancelar" → Landing Page

### 10. Formulário de Voluntário (Landing Page)
- **Componentes:**
  - Campo Nome
  - Campo Contato
  - Campo Área de Interesse
  - Campo Disponibilidade
  - Botão "Cadastrar"
- **Navegação:**
  - "Cadastrar" → Mensagem de sucesso + volta para Landing Page
  - "Cancelar" → Landing Page

## Paleta de Cores
- **Roxo Primário:** #7C3AED
- **Roxo Escuro:** #6D28D9
- **Roxo Claro:** #A78BFA
- **Branco:** #FFFFFF
- **Cinza Claro:** #F3F4F6
- **Cinza Escuro:** #374151
- **Texto:** #1F2937

## Componentes Reutilizáveis
1. **Header** - Com logo e navegação
2. **Sidebar** - Para dashboards
3. **Button** - Botões roxo e branco
4. **Card** - Cartões com sombra
5. **Form** - Formulários com validação visual
6. **Modal** - Para confirmações
7. **Toast** - Para mensagens de sucesso/erro
8. **Table** - Para listagens

## Fluxo de Navegação Principal
```
Landing Page
├── Entrar no Sistema → Login
│   ├── Assistente Social → Dashboard AS
│   │   ├── Cadastrar Mulher → Formulário Mulher
│   │   └── Registrar Serviço → Formulário Serviço
│   └── Administrativo → Dashboard Admin
│       ├── Cadastrar Colaborador → Formulário Colaborador
│       └── Cadastrar Suprimento → Formulário Suprimento
├── Fazer Doação → Formulário Doação
├── Seja Voluntário → Formulário Voluntário
└── Contato → Formulário Contato
```

## Tecnologias
- **React 19** com TypeScript
- **Tailwind CSS 4** para estilização
- **Wouter** para roteamento
- **shadcn/ui** para componentes
- **Lucide React** para ícones
